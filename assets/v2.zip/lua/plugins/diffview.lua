return {
    "sindrets/diffview.nvim"
}